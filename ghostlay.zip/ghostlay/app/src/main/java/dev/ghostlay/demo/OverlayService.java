package dev.ghostlay.demo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    static final String ACTION_STOP = "dev.ghostlay.demo.STOP";
    private static final String TAG = "Ghostlay";
    private static final String CHANNEL = "ghostlay";
    private static final int MAX_TRIES = 20;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TextView overlay;
    private WindowManager.LayoutParams lp;
    private boolean revealed;
    private int tries;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startInForeground();
        if (overlay == null) showOverlay();
        return START_NOT_STICKY;
    }

    private void startInForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Overlay", NotificationManager.IMPORTANCE_MIN));
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Ghostlay is running")
                .setContentText("Tap to stop")
                .setContentIntent(stop)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    private void showOverlay() {
        wm = getSystemService(WindowManager.class);
        float d = getResources().getDisplayMetrics().density;

        TextView tv = new TextView(this);
        tv.setText("Hello World");
        tv.setTextSize(22);
        tv.setTextColor(Color.BLACK);
        int pad = (int) (20 * d);
        tv.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(16 * d);
        tv.setBackground(bg);
        tv.setAlpha(0f); // invisible until the capture-skip flag is on, so no first frame leaks

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (40 * d);
        lp.y = (int) (200 * d);

        tv.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x; startY = lp.y;
                        downX = e.getRawX(); downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = startX + (int) (e.getRawX() - downX);
                        lp.y = startY + (int) (e.getRawY() - downY);
                        wm.updateViewLayout(v, lp);
                        return true;
                }
                return false;
            }
        });

        overlay = tv;
        wm.addView(tv, lp);
        tv.getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);
        handler.post(applyRunnable);
    }

    /** Re-applies the flag after relayouts (rotation, surface re-creation). */
    private final ViewTreeObserver.OnGlobalLayoutListener layoutListener = () -> {
        if (revealed && overlay != null) SkipCapture.apply(overlay, true);
    };

    private final Runnable applyRunnable = new Runnable() {
        @Override public void run() {
            if (overlay == null) return;
            if (SkipCapture.apply(overlay, true)) {
                overlay.setAlpha(1f);
                revealed = true;
                Log.i(TAG, "Overlay hidden from capture after " + tries + " retries");
            } else if (++tries < MAX_TRIES) {
                handler.postDelayed(this, 50);
            } else {
                // Fail closed: never keep an overlay that could be captured.
                Log.e(TAG, "Could not set SKIP_SCREENSHOT; check logcat tag Ghostlay");
                Toast.makeText(OverlayService.this, "Ghostlay: capture-skip failed (see logcat)", Toast.LENGTH_LONG).show();
                stopSelf();
            }
        }
    };

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (overlay != null) {
            try {
                overlay.getViewTreeObserver().removeOnGlobalLayoutListener(layoutListener);
                wm.removeView(overlay);
            } catch (Exception ignored) { }
            overlay = null;
        }
        super.onDestroy();
    }
}
